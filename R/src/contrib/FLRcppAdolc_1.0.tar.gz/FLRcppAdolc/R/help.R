#' Attempting to link FLR and ADOLC using Rcpp
#'
#' Some guff on FLR and Rcpp and ADOLC
#' Very important
#'
#' @import FLCore
#' @docType package
#' @name FLRcppAdolc
#' @aliases FLRcppAdolc, FLRcppAdolc-package
#' @useDynLib FLRcppAdolc
NULL
