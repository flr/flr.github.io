# From Hadley Wickham's wiki on github:https://github.com/hadley/devtools/wiki/Testing
library(testthat)
library(FLRcppAdolc)

test_package("FLRcppAdolc")
