FLRcppAdolc
===========

R package that combines R, Rcpp and ADOL-C

Things to do:
	How to get RcppExports.cpp to look in src/tests
	Add tests
	Tidy up Makevars
	Add clean option to Makevars
	Makevars.win

