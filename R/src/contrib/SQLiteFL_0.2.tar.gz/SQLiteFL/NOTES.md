# Improving SQLite performance

- <http://stackoverflow.com/questions/784173/what-are-the-performance-characteristics-of-sqlite-with-very-large-database-file?>

- <http://web.utk.edu/~jplyon/sqlite/SQLite_optimization_FAQ.html#pragmas>

