### R code from vignette source 'SQLiteFL_internals.Rnw'

###################################################
### code chunk number 1: SQLiteFL_internals.Rnw:29-31
###################################################
options(width=60)
options(continue=" ")


###################################################
### code chunk number 2: SQLiteFL_internals.Rnw:60-61
###################################################
  library(xtable)


###################################################
### code chunk number 3: SQLiteFL_internals.Rnw:65-66
###################################################
  library(SQLiteFL)


