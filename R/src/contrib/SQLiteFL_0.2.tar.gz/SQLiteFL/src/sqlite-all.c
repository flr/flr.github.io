#ifdef RSQLITE_USE_BUNDLED_SQLITE || WIN32
#  include "sqlite/sqlite3.c"
#endif
