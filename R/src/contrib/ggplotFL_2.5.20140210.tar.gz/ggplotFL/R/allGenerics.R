# allGenerics.R - DESC
# allGenerics.R

# Copyright 2003-2013 FLR Team. Distributed under the GPL 2 or later
# Maintainer: Laurie Kell, ICCAT & Iago Mosqueira, JRC
# Notes:

# ggplot 
setGeneric("ggplot", useAsDefault = ggplot2::ggplot)
