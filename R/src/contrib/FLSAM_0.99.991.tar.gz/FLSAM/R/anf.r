  'anf' <-
  function(x) as.numeric(as.character(x)) # alias to convert factors
